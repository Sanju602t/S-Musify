package com.github.musicyou.models

data class Info(
    val id: String,
    val name: String?
)
