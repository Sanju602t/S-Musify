package com.github.musicyou.enums

enum class BuiltInPlaylist {
    Favorites,
    Offline
}
